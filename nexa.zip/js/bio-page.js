/**
 * Nexa Bio — Public Profile Display Engine (bio-page.js)
 * High-performance, responsive public creator bio page
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', async () => {
    const container = document.getElementById('publicBioContainer');
    if (!container) return;

    // 1. Extract handle from URL params (?u=...) or pathname (/@handle)
    const urlParams = new URLSearchParams(window.location.search);
    let handle = urlParams.get('u') || urlParams.get('handle');

    if (!handle && window.location.pathname.includes('/@')) {
      handle = window.location.pathname.split('/@')[1]?.split('/')[0];
    }

    handle = (handle || 'creator').toLowerCase().replace(/[^a-z0-9_]/g, '');

    // 2. Load Creator Profile (First try server API, then localStorage draft, then fallback)
    let bioData = null;

    try {
      if (window.NexaApi && window.NexaApi.fetchBio) {
        const remote = await window.NexaApi.fetchBio(handle);
        if (remote && remote.bio) {
          bioData = remote.bio;
        }
      } else {
        const res = await fetch(`/api/v1/bio/profile?handle=${encodeURIComponent(handle)}`).then(r => r.json()).catch(() => null);
        if (res && res.bio) {
          bioData = res.bio;
        }
      }
    } catch (_) {}

    if (!bioData) {
      try {
        const stored = localStorage.getItem(`nexa_bio_draft_${handle}`) || localStorage.getItem('nexa_bio_current');
        if (stored) {
          bioData = JSON.parse(stored);
        }
      } catch (_) {}
    }

    if (!bioData) {
      bioData = {
        handle: handle,
        name: handle.charAt(0).toUpperCase() + handle.slice(1),
        category: 'Official Creator Bio',
        bio: 'Welcome to my official creator links and resources. Connect with me below 👇',
        verified: true,
        avatarEmoji: '⚡',
        avatarBg: 'linear-gradient(135deg, #6366f1, #ec4899)',
        font: 'font-sora',
        theme: 'theme-editorial-light',
        socials: {
          instagram: handle,
          youtube: '',
          whatsapp: '',
          telegram: '',
          x: ''
        },
        blocks: [
          {
            id: 'b1',
            type: 'link',
            title: 'Explore My Top Content & Resources',
            url: 'https://nexareply.app'
          },
          {
            id: 'b2',
            type: 'whatsapp',
            title: 'Chat 1-on-1 on WhatsApp',
            phone: '919876543210',
            message: `Hi @${handle}! Found your bio link on Nexa.`
          }
        ]
      };
    }

    // 3. Set Document Metadata
    document.title = `${bioData.name} (@${handle}) — Nexa Bio`;

    // 4. Render into container with theme and font classes
    document.body.className = `${bioData.theme || 'theme-editorial-light'} ${bioData.font || 'font-sora'}`;

    const verifiedHtml = bioData.verified !== false
      ? `<span style="display:inline-flex; align-items:center; justify-content:center; width:20px; height:20px; background:#38bdf8; border-radius:50%; color:#fff; font-size:12px; margin-left:6px" title="Verified Creator">✓</span>`
      : '';

    // Social Bar
    const socialIcons = [];
    const socials = bioData.socials || {};
    if (socials.instagram) {
      socialIcons.push(`<a href="https://instagram.com/${escapeHtml(socials.instagram)}" target="_blank" class="bio-social-icon" title="Instagram">📸</a>`);
    }
    if (socials.youtube) {
      const yt = socials.youtube.startsWith('@') ? socials.youtube : `@${socials.youtube}`;
      socialIcons.push(`<a href="https://youtube.com/${escapeHtml(yt)}" target="_blank" class="bio-social-icon" title="YouTube">▶️</a>`);
    }
    if (socials.whatsapp) {
      const cleanPhone = socials.whatsapp.replace(/\D/g, '');
      socialIcons.push(`<a href="https://wa.me/${cleanPhone}" target="_blank" class="bio-social-icon" title="WhatsApp">💬</a>`);
    }
    if (socials.telegram) {
      socialIcons.push(`<a href="https://t.me/${escapeHtml(socials.telegram)}" target="_blank" class="bio-social-icon" title="Telegram">✈️</a>`);
    }
    if (socials.x) {
      socialIcons.push(`<a href="https://x.com/${escapeHtml(socials.x)}" target="_blank" class="bio-social-icon" title="X (Twitter)">🐦</a>`);
    }

    const socialsRowHtml = socialIcons.length
      ? `<div class="bio-socials-row" style="display:flex; justify-content:center; gap:14px; margin-bottom:24px">${socialIcons.join('')}</div>`
      : '';

    // Content Blocks
    const blocksHtml = (bioData.blocks || []).map(b => {
      if (b.type === 'product') {
        return `
          <a href="${escapeHtml(b.url || '#')}" target="_blank" class="bio-block-item bio-product-card" style="display:block; text-decoration:none; padding:18px 20px; border-radius:16px; margin-bottom:12px; transition:transform 0.2s">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px">
              <span class="bio-product-title" style="font-weight:800; font-size:1rem">${escapeHtml(b.title)}</span>
              <span class="bio-product-price" style="font-weight:900; color:#10b981; font-size:1.1rem">${escapeHtml(b.price || '')}</span>
            </div>
            ${b.badge ? `<span style="font-size:0.72rem; background:rgba(236,72,153,0.18); color:#ec4899; padding:3px 10px; border-radius:99px; font-weight:800">${escapeHtml(b.badge)}</span>` : ''}
          </a>
        `;
      } else if (b.type === 'whatsapp') {
        const phone = (b.phone || '919876543210').replace(/\D/g, '');
        const msg = encodeURIComponent(b.message || 'Hi!');
        return `
          <a href="https://wa.me/${phone}?text=${msg}" target="_blank" class="bio-block-item bio-whatsapp-card" style="display:flex; align-items:center; justify-content:space-between; text-decoration:none; padding:16px 20px; border-radius:16px; margin-bottom:12px;">
            <span style="font-weight:800; font-size:0.95rem">💬 ${escapeHtml(b.title)}</span>
            <span style="font-size:0.75rem; background:#25D366; color:#fff; padding:4px 12px; border-radius:99px; font-weight:800">Chat Now</span>
          </a>
        `;
      } else {
        return `
          <a href="${escapeHtml(b.url || '#')}" target="_blank" class="bio-block-item bio-link-card" style="display:block; text-decoration:none; padding:16px 20px; border-radius:16px; margin-bottom:12px; text-align:center; font-weight:800; font-size:0.95rem">
            ${escapeHtml(b.title)}
          </a>
        `;
      }
    }).join('');

    container.innerHTML = `
      <div style="max-width:540px; margin:40px auto; padding:0 20px">
        <div style="width:84px; height:84px; border-radius:50%; margin:0 auto 16px auto; display:flex; align-items:center; justify-content:center; font-size:2.2rem; background:${bioData.avatarBg || 'linear-gradient(135deg, #6366f1, #ec4899)'}; box-shadow:0 10px 30px rgba(0,0,0,0.15)">
          ${bioData.avatarEmoji || '⚡'}
        </div>

        <h1 class="bio-text-name" style="font-size:1.6rem; font-weight:900; text-align:center; margin-bottom:6px; display:flex; align-items:center; justify-content:center;">
          ${escapeHtml(bioData.name)} ${verifiedHtml}
        </h1>

        <div class="bio-text-category" style="font-size:0.82rem; text-align:center; color:#94a3b8; font-weight:700; margin-bottom:12px">
          ${escapeHtml(bioData.category)}
        </div>

        <p class="bio-text-sub" style="font-size:0.88rem; text-align:center; line-height:1.6; margin-bottom:24px; padding:0 12px">
          ${escapeHtml(bioData.bio)}
        </p>

        ${socialsRowHtml}

        <div style="margin-bottom:32px">
          ${blocksHtml}
        </div>

        <div style="text-align:center; padding:24px 0; font-size:0.75rem; color:#94a3b8; border-top:1px solid rgba(0,0,0,0.06)">
          ⚡ Powered by <a href="https://nexareply.app" style="color:var(--primary); font-weight:800; text-decoration:none">Nexa Reply</a>
        </div>
      </div>
    `;
  });

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
})();
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
})();
