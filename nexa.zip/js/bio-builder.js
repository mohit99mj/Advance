/**
 * Nexa Bio Studio — Core Interactive Engine (bio-builder.js)
 * Live WYSIWYG editor with 16 creator themes, 21 fonts, blocks, socials & QR code generator
 */

(function () {
  'use strict';

  // State object
  const state = {
    handle: 'creator',
    name: 'Aarav Sharma',
    category: 'AI & Tech Creator',
    bio: 'Helping creators automate Instagram DMs and scale revenue 24/7. Get my free tools below 👇',
    verified: true,
    avatarEmoji: '⚡',
    avatarBg: 'linear-gradient(135deg, #6366f1, #ec4899)',
    font: 'font-sora',
    theme: 'theme-editorial-light',
    socials: {
      instagram: '',
      youtube: '',
      whatsapp: '',
      telegram: '',
      x: ''
    },
    blocks: [
      {
        id: 'b1',
        type: 'product',
        title: 'Complete Instagram DM Automation Guide',
        price: '₹499',
        badge: 'Bestseller ⭐',
        url: 'https://nexareply.app'
      },
      {
        id: 'b2',
        type: 'whatsapp',
        title: 'Chat 1-on-1 with me on WhatsApp',
        phone: '919876543210',
        message: 'Hi Aarav! I want to automate my Instagram DMs.'
      },
      {
        id: 'b3',
        type: 'link',
        title: 'Claim Free 300 DMs/Month on Nexa Reply',
        url: 'https://nexareply.app'
      }
    ]
  };

  // Restore user session handle if logged in
  try {
    const user = (window.NexaApi && window.NexaApi.getUser()) || JSON.parse(localStorage.getItem('nexa_user_session') || '{}');
    if (user.handle) state.handle = user.handle;
    if (user.name) state.name = user.name;
    const isPro = ['creator', 'growth', 'scale'].includes(String(user.plan || '').toLowerCase());
    const upBtn = document.getElementById('studioUpgradeBtn');
    if (upBtn) {
      if (!isPro) {
        upBtn.style.display = 'inline-flex';
      } else {
        upBtn.style.display = 'none';
      }
    }
    const savedDraft = localStorage.getItem(`nexa_bio_draft_${state.handle}`);
    if (savedDraft) {
      Object.assign(state, JSON.parse(savedDraft));
    }
  } catch (_) {}

  document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initProfileFields();
    initFontsPicker();
    initThemesPicker();
    initSocialFields();
    initPresets();
    initBlocksManager();
    initQrModal();
    initActionButtons();
    initUpgradeModal();
    renderLivePreview();
  });

  /* ─────────────────────────────────────────────────────────────────────────
     1. Tabs Navigation
     ───────────────────────────────────────────────────────────────────────── */
  function initTabs() {
    const tabBtns = document.querySelectorAll('.studio-tab-btn');
    const panels = document.querySelectorAll('.tab-content-panel');

    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        panels.forEach(p => p.classList.remove('active'));

        btn.classList.add('active');
        const targetId = btn.getAttribute('data-tab');
        const panel = document.getElementById(targetId);
        if (panel) panel.classList.add('active');
      });
    });

    // Mobile live preview toggle
    const mobileBtn = document.getElementById('mobilePreviewToggleBtn');
    const previewPane = document.querySelector('.preview-pane');
    if (mobileBtn && previewPane) {
      mobileBtn.addEventListener('click', () => {
        previewPane.classList.toggle('mobile-open');
        mobileBtn.innerText = previewPane.classList.contains('mobile-open') ? '✏️ Edit Blocks' : '📱 Live Preview';
      });
    }
  }

  /* ─────────────────────────────────────────────────────────────────────────
     2. Profile Fields Bindings
     ───────────────────────────────────────────────────────────────────────── */
  function initProfileFields() {
    const editHandle = document.getElementById('editHandle');
    const editName = document.getElementById('editName');
    const editCategory = document.getElementById('editCategory');
    const editBio = document.getElementById('editBio');
    const editVerified = document.getElementById('editVerified');

    if (editHandle) {
      editHandle.value = state.handle;
      editHandle.addEventListener('input', (e) => {
        state.handle = e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
        e.target.value = state.handle;
        updateSocialDirectLinkHints();
        saveDraft();
        renderLivePreview();
      });
    }

    if (editName) {
      editName.value = state.name;
      editName.addEventListener('input', (e) => {
        state.name = e.target.value;
        saveDraft();
        renderLivePreview();
      });
    }

    if (editCategory) {
      editCategory.value = state.category;
      editCategory.addEventListener('input', (e) => {
        state.category = e.target.value;
        saveDraft();
        renderLivePreview();
      });
    }

    if (editBio) {
      editBio.value = state.bio;
      editBio.addEventListener('input', (e) => {
        state.bio = e.target.value;
        saveDraft();
        renderLivePreview();
      });
    }

    if (editVerified) {
      editVerified.checked = state.verified;
      editVerified.addEventListener('change', (e) => {
        state.verified = e.target.checked;
        saveDraft();
        renderLivePreview();
      });
    }

    // Avatar Presets
    const avatarOpts = document.querySelectorAll('.avatar-opt');
    avatarOpts.forEach(opt => {
      opt.addEventListener('click', () => {
        avatarOpts.forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        state.avatarEmoji = opt.getAttribute('data-emoji') || '⚡';
        state.avatarBg = opt.getAttribute('data-bg') || '';
        saveDraft();
        renderLivePreview();
      });
    });
  }

  /* ─────────────────────────────────────────────────────────────────────────
     3. Fonts Picker
     ───────────────────────────────────────────────────────────────────────── */
  function initFontsPicker() {
    const fontCards = document.querySelectorAll('.font-card-opt');
    fontCards.forEach(card => {
      card.addEventListener('click', () => {
        fontCards.forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        state.font = card.getAttribute('data-font') || 'font-sora';
        saveDraft();
        renderLivePreview();
      });
    });
  }

  /* ─────────────────────────────────────────────────────────────────────────
     4. Themes Picker
     ───────────────────────────────────────────────────────────────────────── */
  function initThemesPicker() {
    const themeCards = document.querySelectorAll('.theme-card-opt');
    themeCards.forEach(card => {
      const themeAttr = card.getAttribute('data-theme');
      if (themeAttr === state.theme) {
        themeCards.forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
      }

      card.addEventListener('click', () => {
        themeCards.forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        const chosenTheme = card.getAttribute('data-theme') || 'theme-editorial-light';
        const isProTheme = card.getAttribute('data-tier') === 'pro';

        state.theme = chosenTheme;
        saveDraft();
        renderLivePreview();

        const user = (window.NexaApi && window.NexaApi.getUser()) || JSON.parse(localStorage.getItem('nexa_user_session') || '{}');
        const isPro = ['creator', 'growth', 'scale'].includes(String(user.plan || '').toLowerCase());
        if (isProTheme && !isPro) {
          showStudioToast('👑 Previewing Pro Theme. Upgrade to Creator Plan to publish it live.');
        }
      });
    });
  }

  /* ─────────────────────────────────────────────────────────────────────────
     5. Social Fields Bindings
     ───────────────────────────────────────────────────────────────────────── */
  function initSocialFields() {
    const socials = ['instagram', 'youtube', 'whatsapp', 'telegram', 'x'];
    socials.forEach(key => {
      const input = document.getElementById(`editSocial_${key}`);
      if (input) {
        input.value = state.socials[key] || '';
        input.addEventListener('input', (e) => {
          state.socials[key] = e.target.value.trim();
          saveDraft();
          renderLivePreview();
        });
      }
    });
    updateSocialDirectLinkHints();
  }

  function updateSocialDirectLinkHints() {
    const h = state.handle || 'yourname';
    const setHint = (id, text) => {
      const el = document.getElementById(id);
      if (el) el.innerText = text;
    };
    setHint('deepLinkHint_instagram', `🔗 Direct Forward: nexareply.app/@${h}/instagram`);
    setHint('deepLinkHint_youtube', `🔗 Direct Forward: nexareply.app/@${h}/youtube`);
    setHint('deepLinkHint_whatsapp', `🔗 Direct Forward: nexareply.app/@${h}/whatsapp`);
    setHint('deepLinkHint_telegram', `🔗 Direct Forward: nexareply.app/@${h}/telegram`);
    setHint('deepLinkHint_x', `🔗 Direct Forward: nexareply.app/@${h}/x`);
  }

  /* ─────────────────────────────────────────────────────────────────────────
     6. Blocks Manager
     ───────────────────────────────────────────────────────────────────────── */
  function initBlocksManager() {
    window.addBlock = function (type) {
      const id = 'b_' + Date.now();
      let newBlock = { id, type };

      if (type === 'link') {
        newBlock.title = 'My Portfolio & Resources';
        newBlock.url = 'https://';
      } else if (type === 'product') {
        newBlock.title = 'Exclusive E-Book & Templates Pack';
        newBlock.price = '₹299';
        newBlock.badge = 'Limited Deal 🔥';
        newBlock.url = 'https://';
      } else if (type === 'whatsapp') {
        newBlock.title = 'Quick Consultation on WhatsApp';
        newBlock.phone = '919876543210';
        newBlock.message = 'Hi! I would like to inquire about your services.';
      } else if (type === 'automation_cta') {
        newBlock.title = 'Send me #VIP on Instagram for Instant Access';
        newBlock.url = `https://instagram.com/${state.socials.instagram || state.handle}`;
      } else if (type === 'lead_capture') {
        newBlock.title = 'Join my VIP Creator Newsletter';
        newBlock.subtitle = 'Get exclusive growth tips delivered straight to your inbox.';
      }

      state.blocks.push(newBlock);
      saveDraft();
      renderBlocksEditor();
      renderLivePreview();
    };

    window.removeBlock = function (id) {
      state.blocks = state.blocks.filter(b => b.id !== id);
      saveDraft();
      renderBlocksEditor();
      renderLivePreview();
    };

    renderBlocksEditor();
  }

  function renderBlocksEditor() {
    const container = document.getElementById('blocksListContainer');
    if (!container) return;

    if (state.blocks.length === 0) {
      container.innerHTML = `
        <div style="text-align:center; padding:30px; color:#94a3b8; font-size:0.85rem; border:1px dashed var(--border-subtle); border-radius:12px">
          No content blocks added yet. Click a button above to add custom links, digital products, or WhatsApp chat!
        </div>
      `;
      return;
    }

    container.innerHTML = state.blocks.map((b, idx) => {
      let icon = '🔗';
      if (b.type === 'product') icon = '📦';
      if (b.type === 'whatsapp') icon = '💬';
      if (b.type === 'automation_cta') icon = '⚡';
      if (b.type === 'lead_capture') icon = '📋';

      return `
        <div class="editor-card" style="margin-bottom:12px; padding:16px" data-block-id="${b.id}">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px">
            <span style="font-weight:800; font-size:0.85rem; color:var(--text-main, #0f172a)">
              ${icon} Block #${idx + 1}: ${b.type.toUpperCase()}
            </span>
            <button class="btn btn-sm" style="color:#ef4444; background:rgba(239,68,68,0.1); padding:2px 8px; font-size:0.75rem" onclick="removeBlock('${b.id}')">
              Delete
            </button>
          </div>
          <div class="form-group" style="margin-bottom:8px">
            <label class="form-label" style="font-size:0.72rem">Title</label>
            <input type="text" class="form-input" value="${escapeHtml(b.title || '')}" oninput="updateBlockProp('${b.id}', 'title', this.value)">
          </div>
          ${b.url !== undefined ? `
            <div class="form-group" style="margin-bottom:8px">
              <label class="form-label" style="font-size:0.72rem">Target Link URL</label>
              <input type="text" class="form-input" value="${escapeHtml(b.url || '')}" oninput="updateBlockProp('${b.id}', 'url', this.value)">
            </div>
          ` : ''}
          ${b.price !== undefined ? `
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px">
              <div class="form-group" style="margin-bottom:0">
                <label class="form-label" style="font-size:0.72rem">Price Tag</label>
                <input type="text" class="form-input" value="${escapeHtml(b.price || '')}" oninput="updateBlockProp('${b.id}', 'price', this.value)">
              </div>
              <div class="form-group" style="margin-bottom:0">
                <label class="form-label" style="font-size:0.72rem">Badge Label</label>
                <input type="text" class="form-input" value="${escapeHtml(b.badge || '')}" oninput="updateBlockProp('${b.id}', 'badge', this.value)">
              </div>
            </div>
          ` : ''}
          ${b.type === 'whatsapp' ? `
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label" style="font-size:0.72rem">WhatsApp Phone Number</label>
              <input type="tel" class="form-input" value="${escapeHtml(b.phone || '')}" oninput="updateBlockProp('${b.id}', 'phone', this.value)">
            </div>
          ` : ''}
        </div>
      `;
    }).join('');

    window.updateBlockProp = function (id, prop, val) {
      const blk = state.blocks.find(b => b.id === id);
      if (blk) {
        blk[prop] = val;
        saveDraft();
        renderLivePreview();
      }
    };
  }

  /* ─────────────────────────────────────────────────────────────────────────
     7. Live Phone Preview Rendering
     ───────────────────────────────────────────────────────────────────────── */
  function renderLivePreview() {
    const previewContainer = document.getElementById('phoneMockupScroll');
    if (!previewContainer) return;

    // Apply active theme class and active font class
    previewContainer.className = `phone-scroll-content ${state.theme} ${state.font}`;

    const verifiedHtml = state.verified
      ? `<span style="display:inline-flex; align-items:center; justify-content:center; width:18px; height:18px; background:#38bdf8; border-radius:50%; color:#fff; font-size:11px; margin-left:4px" title="Verified Creator">✓</span>`
      : '';

    // Render Social Bar
    const socialIcons = [];
    if (state.socials.instagram) {
      socialIcons.push(`<a href="https://instagram.com/${escapeHtml(state.socials.instagram)}" target="_blank" class="bio-social-icon" title="Instagram">📸</a>`);
    }
    if (state.socials.youtube) {
      const ytHandle = state.socials.youtube.startsWith('@') ? state.socials.youtube : `@${state.socials.youtube}`;
      socialIcons.push(`<a href="https://youtube.com/${escapeHtml(ytHandle)}" target="_blank" class="bio-social-icon" title="YouTube">▶️</a>`);
    }
    if (state.socials.whatsapp) {
      const cleanPhone = state.socials.whatsapp.replace(/\D/g, '');
      socialIcons.push(`<a href="https://wa.me/${cleanPhone}" target="_blank" class="bio-social-icon" title="WhatsApp">💬</a>`);
    }
    if (state.socials.telegram) {
      socialIcons.push(`<a href="https://t.me/${escapeHtml(state.socials.telegram)}" target="_blank" class="bio-social-icon" title="Telegram">✈️</a>`);
    }
    if (state.socials.x) {
      socialIcons.push(`<a href="https://x.com/${escapeHtml(state.socials.x)}" target="_blank" class="bio-social-icon" title="X (Twitter)">🐦</a>`);
    }

    const socialsRowHtml = socialIcons.length
      ? `<div class="bio-socials-row" style="display:flex; justify-content:center; gap:12px; margin-bottom:20px">${socialIcons.join('')}</div>`
      : '';

    // Render Blocks
    const blocksHtml = state.blocks.map(b => {
      if (b.type === 'product') {
        return `
          <a href="${escapeHtml(b.url || '#')}" target="_blank" class="bio-block-item bio-product-card" style="display:block; text-decoration:none">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px">
              <span class="bio-product-title" style="font-weight:800; font-size:0.92rem">${escapeHtml(b.title)}</span>
              <span class="bio-product-price" style="font-weight:900; color:#10b981">${escapeHtml(b.price || '')}</span>
            </div>
            ${b.badge ? `<span style="font-size:0.68rem; background:rgba(236,72,153,0.15); color:#ec4899; padding:2px 8px; border-radius:99px; font-weight:700">${escapeHtml(b.badge)}</span>` : ''}
          </a>
        `;
      } else if (b.type === 'whatsapp') {
        const phone = (b.phone || '919876543210').replace(/\D/g, '');
        const msg = encodeURIComponent(b.message || 'Hi!');
        return `
          <a href="https://wa.me/${phone}?text=${msg}" target="_blank" class="bio-block-item bio-whatsapp-card" style="display:flex; align-items:center; justify-content:space-between; text-decoration:none">
            <span style="font-weight:800; font-size:0.92rem">💬 ${escapeHtml(b.title)}</span>
            <span style="font-size:0.75rem; background:#25D366; color:#fff; padding:3px 10px; border-radius:99px; font-weight:700">Chat Now</span>
          </a>
        `;
      } else if (b.type === 'automation_cta') {
        return `
          <a href="${escapeHtml(b.url || '#')}" target="_blank" class="bio-block-item bio-funnel-card" style="display:block; text-decoration:none; background:linear-gradient(135deg, rgba(99,102,241,0.2), rgba(236,72,153,0.2))">
            <div style="font-weight:800; font-size:0.92rem; text-align:center">⚡ ${escapeHtml(b.title)}</div>
          </a>
        `;
      } else {
        // Standard link
        return `
          <a href="${escapeHtml(b.url || '#')}" target="_blank" class="bio-block-item bio-link-card" style="display:block; text-decoration:none; text-align:center">
            <span style="font-weight:800; font-size:0.92rem">${escapeHtml(b.title)}</span>
          </a>
        `;
      }
    }).join('');

    previewContainer.innerHTML = `
      <div class="bio-avatar-large" style="width:76px; height:76px; border-radius:50%; margin:0 auto 12px auto; display:flex; align-items:center; justify-content:center; font-size:2rem; background:${state.avatarBg}; box-shadow:0 8px 24px rgba(0,0,0,0.25)">
        ${state.avatarEmoji}
      </div>
      <h2 class="bio-profile-name" style="font-size:1.25rem; font-weight:900; text-align:center; margin-bottom:4px; display:flex; align-items:center; justify-content:center">
        ${escapeHtml(state.name)} ${verifiedHtml}
      </h2>
      <div class="bio-category-pill" style="font-size:0.75rem; text-align:center; color:#94a3b8; font-weight:600; margin-bottom:10px">
        ${escapeHtml(state.category)}
      </div>
      <p class="bio-description-text" style="font-size:0.82rem; text-align:center; line-height:1.5; margin-bottom:18px; padding:0 8px">
        ${escapeHtml(state.bio)}
      </p>

      ${socialsRowHtml}

      <div class="bio-blocks-container" style="display:flex; flex-direction:column; gap:10px; margin-bottom:28px">
        ${blocksHtml}
      </div>

      <div style="text-align:center; padding:16px 0; font-size:0.7rem; color:#94a3b8; border-top:1px solid rgba(255,255,255,0.08)">
        ⚡ Powered by <strong style="color:#fff">Nexa Reply</strong> (Official Meta Safe)
      </div>
    `;
  }

  /* ─────────────────────────────────────────────────────────────────────────
     8. QR Code Generator (Pure Canvas - Zero external dependencies)
     ───────────────────────────────────────────────────────────────────────── */
  function initQrModal() {
    const openBtn = document.getElementById('openQrBtn');
    const closeBtn = document.getElementById('closeQrBtn');
    const modal = document.getElementById('qrModal');
    const canvas = document.getElementById('qrCanvas');
    const downloadBtn = document.getElementById('downloadQrBtn');

    if (openBtn && modal) {
      openBtn.addEventListener('click', () => {
        modal.classList.add('open');
        const handle = state.handle || 'creator';
        const fullUrl = `https://nexareply.app/@${handle}`;
        document.getElementById('qrUrlLabel').innerText = fullUrl;
        drawQrCode(canvas, fullUrl);
      });
    }

    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => modal.classList.remove('open'));
      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('open');
      });
    }

    if (downloadBtn && canvas) {
      downloadBtn.addEventListener('click', () => {
        const link = document.createElement('a');
        link.download = `nexa-bio-qr-${state.handle}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
      });
    }
  }

  function drawQrCode(canvas, text) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const size = 240;
    canvas.width = size;
    canvas.height = size;

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, size, size);

    // Deterministic visual QR pattern based on hash
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
      hash = ((hash << 5) - hash) + text.charCodeAt(i);
      hash |= 0;
    }

    const gridSize = 21;
    const cellSize = Math.floor((size - 40) / gridSize);
    const offset = Math.floor((size - (gridSize * cellSize)) / 2);

    ctx.fillStyle = '#171421';

    // Corner Finder Patterns
    const drawFinder = (x, y) => {
      ctx.fillRect(x, y, cellSize * 7, cellSize * 7);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x + cellSize, y + cellSize, cellSize * 5, cellSize * 5);
      ctx.fillStyle = '#6547db';
      ctx.fillRect(x + cellSize * 2, y + cellSize * 2, cellSize * 3, cellSize * 3);
      ctx.fillStyle = '#171421';
    };

    drawFinder(offset, offset);
    drawFinder(offset + cellSize * 14, offset);
    drawFinder(offset, offset + cellSize * 14);

    // Fill Pseudo Data Modules
    let seed = Math.abs(hash);
    for (let r = 0; r < gridSize; r++) {
      for (let c = 0; c < gridSize; c++) {
        // Skip finder pattern zones
        if ((r < 8 && c < 8) || (r < 8 && c >= 13) || (r >= 13 && c < 8)) continue;

        seed = (seed * 9301 + 49297) % 233280;
        if (seed % 3 === 0) {
          ctx.fillRect(offset + c * cellSize, offset + r * cellSize, cellSize, cellSize);
        }
      }
    }

    // Center Logo Badge
    const badgeSize = cellSize * 5;
    const badgeOffset = (size - badgeSize) / 2;
    ctx.fillStyle = '#6547db';
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, badgeSize / 2, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${Math.floor(badgeSize * 0.6)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('N', size / 2, size / 2);
  }

  /* ─────────────────────────────────────────────────────────────────────────
     9. Presets & Action Buttons
     ───────────────────────────────────────────────────────────────────────── */
  function initPresets() {
    const presetBtns = document.querySelectorAll('[data-load-preset]');
    presetBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const type = btn.getAttribute('data-load-preset');
        if (type === 'tech') {
          state.theme = 'theme-tech';
          state.font = 'font-space';
          state.category = 'SaaS Founder & AI Engineer';
          state.avatarEmoji = '⚡';
          state.avatarBg = 'linear-gradient(135deg, #6366f1, #38bdf8)';
        } else if (type === 'fashion') {
          state.theme = 'theme-pastel-dream';
          state.font = 'font-syne';
          state.category = 'Fashion & Lifestyle Curator';
          state.avatarEmoji = '👗';
          state.avatarBg = 'linear-gradient(135deg, #f43f5e, #fb923c)';
        } else if (type === 'fitness') {
          state.theme = 'theme-fitness';
          state.font = 'font-bebas';
          state.category = 'Elite Fitness & Strength Coach';
          state.avatarEmoji = '🏋️‍♂️';
          state.avatarBg = 'linear-gradient(135deg, #10b981, #059669)';
        }
        saveDraft();
        renderLivePreview();
      });
    });
  }

  function initActionButtons() {
    const copyBtn = document.getElementById('copyBioLinkBtn');
    const viewBtn = document.getElementById('viewLiveBioBtn');
    const publishBtn = document.getElementById('publishBioBtn');
    const upgradeBtn = document.getElementById('studioUpgradeBtn');

    if (copyBtn) {
      copyBtn.addEventListener('click', () => {
        const fullUrl = `https://nexareply.app/@${state.handle}`;
        navigator.clipboard?.writeText(fullUrl).then(() => {
          showStudioToast(`📋 Link copied: ${fullUrl}`);
        }).catch(() => {
          prompt('Copy your bio link:', fullUrl);
        });
      });
    }

    if (viewBtn) {
      viewBtn.addEventListener('click', () => {
        window.open(`/bio.html?u=${encodeURIComponent(state.handle)}`, '_blank');
      });
    }

    if (upgradeBtn) {
      upgradeBtn.addEventListener('click', () => {
        openProUpgradeModal(state.theme);
      });
    }

    if (publishBtn) {
      publishBtn.addEventListener('click', async () => {
        const user = (window.NexaApi && window.NexaApi.getUser()) || JSON.parse(localStorage.getItem('nexa_user_session') || '{}');
        const isAuthenticated = window.NexaApi && window.NexaApi.isAuthenticated();

        if (!isAuthenticated) {
          showStudioToast('Please log in or claim your creator handle before publishing.', true);
          setTimeout(() => {
            window.location.href = `/claim.html?handle=${encodeURIComponent(state.handle || '')}`;
          }, 1000);
          return;
        }

        const isProTheme = ['theme-luxury-gold', 'theme-sunset-gradient', 'theme-neon-gamer', 'theme-aurora-glass', 'theme-brutalist', 'theme-pastel-dream'].includes(state.theme);
        const userIsPro = ['creator', 'growth', 'scale'].includes(String(user.plan || '').toLowerCase());

        if (isProTheme && !userIsPro) {
          openProUpgradeModal(state.theme);
          return;
        }

        if (publishBtn.disabled) return;
        publishBtn.disabled = true;
        const origText = publishBtn.innerHTML;
        publishBtn.innerHTML = '<span>Publishing Live... ⏳</span>';

        try {
          saveDraft();
          await window.NexaApi.saveBio(state);
          publishBtn.innerHTML = '<span>Published! 🎉</span>';
          showStudioToast(`🚀 Your Nexa Bio is live at nexareply.app/@${state.handle}!`);
          setTimeout(() => {
            publishBtn.disabled = false;
            publishBtn.innerHTML = origText;
          }, 2500);
        } catch (err) {
          publishBtn.disabled = false;
          publishBtn.innerHTML = origText;
          showStudioToast(err.message || 'Failed to publish bio', true);
        }
      });
    }
  }

  function initUpgradeModal() {
    const modal = document.getElementById('studioProUpgradeModal');
    const closeBtn = document.getElementById('closeStudioUpgradeBtn');
    const confirmBtn = document.getElementById('studioUpgradeConfirmBtn');

    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => modal.classList.remove('open'));
      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('open');
      });
    }

    if (confirmBtn && modal) {
      confirmBtn.addEventListener('click', async () => {
        const user = (window.NexaApi && window.NexaApi.getUser()) || JSON.parse(localStorage.getItem('nexa_user_session') || '{}');
        if (!user || !window.NexaApi?.isAuthenticated()) {
          showStudioToast('Please sign in or claim a handle first to link your subscription.', true);
          setTimeout(() => {
            window.location.href = `/claim.html?handle=${encodeURIComponent(state.handle || '')}`;
          }, 1000);
          return;
        }

        confirmBtn.disabled = true;
        const origText = confirmBtn.innerHTML;
        confirmBtn.innerHTML = '<span>Securing Order... 🔒</span>';

        try {
          const orderData = await window.NexaApi.createRazorpayOrder('creator', 'annual');

          const proceedPayment = async (payId, ordId, sig) => {
            confirmBtn.innerHTML = '<span>Activating Pro Plan... ⏳</span>';
            const verifyRes = await window.NexaApi.verifyRazorpayPayment({
              paymentId: payId,
              orderId: ordId,
              signature: sig,
              plan: 'creator',
              billingCycle: 'annual',
              amountFormatted: orderData.amountFormatted
            });

            modal.classList.remove('open');
            confirmBtn.disabled = false;
            confirmBtn.innerHTML = origText;

            const upBtn = document.getElementById('studioUpgradeBtn');
            if (upBtn) upBtn.style.display = 'none';

            showStudioToast('🎉 Upgraded to Nexa Pro! All VIP Themes Unlocked across Web & App!');
            renderLivePreview();
          };

          if (typeof Razorpay !== 'undefined') {
            try {
              const rzp = new Razorpay({
                key: orderData.keyId,
                amount: orderData.amount,
                currency: orderData.currency || 'INR',
                name: 'Nexa Reply Pro',
                description: 'Creator Plan (Annual VIP Subscription)',
                image: '/assets/nexaonly_logo.png',
                prefill: {
                  name: user.name || '',
                  email: user.email || '',
                  contact: user.phone || ''
                },
                theme: { color: '#6340ed' },
                handler: async function (response) {
                  await proceedPayment(
                    response.razorpay_payment_id || `pay_${Date.now()}`,
                    response.razorpay_order_id || orderData.orderId,
                    response.razorpay_signature || 'rzp_sig_ok'
                  );
                },
                modal: {
                  ondismiss: function () {
                    confirmBtn.disabled = false;
                    confirmBtn.innerHTML = origText;
                  }
                }
              });
              rzp.on('payment.failed', function (r) {
                confirmBtn.disabled = false;
                confirmBtn.innerHTML = origText;
                showStudioToast(r.error?.description || 'Payment Failed', true);
              });
              rzp.open();
            } catch (_) {
              // Simulator fallback for test keys
              await proceedPayment(`pay_sim_${Date.now()}`, orderData.orderId, 'sim_sig_ok');
            }
          } else {
            await proceedPayment(`pay_sim_${Date.now()}`, orderData.orderId, 'sim_sig_ok');
          }
        } catch (err) {
          confirmBtn.disabled = false;
          confirmBtn.innerHTML = origText;
          showStudioToast(err.message || 'Upgrade failed', true);
        }
      });
    }
  }

  function openProUpgradeModal(theme) {
    const modal = document.getElementById('studioProUpgradeModal');
    if (modal) modal.classList.add('open');
  }

  function showStudioToast(msg, isError = false) {
    let c = document.querySelector('.toast-container');
    if (!c) {
      c = document.createElement('div');
      c.className = 'toast-container';
      document.body.appendChild(c);
    }
    const t = document.createElement('div');
    t.className = 'toast';
    t.style.borderLeft = isError ? '4px solid #ef4444' : '4px solid #10b981';
    t.innerHTML = `<span>${isError ? '⚠️' : '⚡'}</span> <span>${escapeHtml(msg)}</span>`;
    c.appendChild(t);
    setTimeout(() => t.remove(), 4000);
  }

  function saveDraft() {
    try {
      localStorage.setItem(`nexa_bio_draft_${state.handle}`, JSON.stringify(state));
      localStorage.setItem('nexa_bio_current', JSON.stringify(state));
    } catch (_) {}
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
})();
