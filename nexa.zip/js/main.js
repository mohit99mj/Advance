/**
 * Nexa Reply (nexareply.app) — Main Enterprise Platform Script
 * Features:
 * - Live Instagram Comment-to-DM Simulator with Spintax rotation
 * - Web Login & Mandatory Phone Number Verification (Email/Google + OTP)
 * - Direct Automation Control Center (Toggle Automations ON/OFF from Web)
 * - Claim Free Username Engine (nexareply.app/@username)
 * - Templates Hub (16 Bio Templates + 7 Reply Templates with Filters)
 * - India DPDP Act 2023 Cookie Consent Manager
 * - Network Connectivity Wrapper (Offline / Online Toast)
 * - Real Google Play & APK Download Connectors
 */

document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initNetworkDetector();
  initSimulator();
  initPricingToggle();
  initRoiCalculator();
  initFaqAccordion();
  initAuthSystem();
  updateNavForLoggedInUser();
  initPricingCheckout();
  initAutomationControlCenter();
  initClaimUsernameEngine();
  initTemplatesHub();
  initCookieConsent();
  initDownloadButtons();
});

/* ─────────────────────────────────────────────────────────────────────────────
   1. Header Scroll & Mobile Navigation
   ───────────────────────────────────────────────────────────────────────────── */
function initNavbar() {
  const header = document.querySelector('.site-header');
  const menuBtn = document.querySelector('.mobile-menu-btn');
  const drawer = document.querySelector('.mobile-nav-drawer');
  const backdrop = document.querySelector('.drawer-backdrop');
  const drawerClose = document.querySelector('.drawer-close');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      header?.classList.add('scrolled');
    } else {
      header?.classList.remove('scrolled');
    }
  });

  const toggleDrawer = (open) => {
    if (open) {
      drawer?.classList.add('open');
      backdrop?.classList.add('open');
      document.body.style.overflow = 'hidden';
    } else {
      drawer?.classList.remove('open');
      backdrop?.classList.remove('open');
      document.body.style.overflow = '';
    }
  };

  menuBtn?.addEventListener('click', () => toggleDrawer(true));
  drawerClose?.addEventListener('click', () => toggleDrawer(false));
  backdrop?.addEventListener('click', () => toggleDrawer(false));

  document.querySelectorAll('.drawer-links a').forEach(link => {
    link.addEventListener('click', () => toggleDrawer(false));
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   2. Network Connectivity Wrapper (Matching Mobile ConnectivityWrapper)
   ───────────────────────────────────────────────────────────────────────────── */
function initNetworkDetector() {
  const pill = document.createElement('div');
  pill.className = 'network-pill';
  document.body.appendChild(pill);

  const setNetworkStatus = (online) => {
    if (online) {
      pill.className = 'network-pill online show';
      pill.innerHTML = '<span>●</span> <span>Back online ✅</span>';
      setTimeout(() => {
        pill.classList.remove('show');
      }, 3000);
    } else {
      pill.className = 'network-pill offline show';
      pill.innerHTML = '<span>●</span> <span>Offline mode • Showing cached data</span>';
    }
  };

  window.addEventListener('offline', () => setNetworkStatus(false));
  window.addEventListener('online', () => setNetworkStatus(true));
}

/* ─────────────────────────────────────────────────────────────────────────────
   3. Web Authentication & Mandatory Phone Verification System
   ───────────────────────────────────────────────────────────────────────────── */
let currentUser = null;

const firebaseConfig = {
  apiKey: "AIzaSyDBojZa5QPvMZ9o6XxjwUh0qEqldGHg7fQ",
  authDomain: "nexareplyautomation.firebaseapp.com",
  projectId: "nexareplyautomation",
  storageBucket: "nexareplyautomation.firebasestorage.app",
  messagingSenderId: "320420668849",
  appId: "1:320420668849:web:8a5db9920e490e5a358990",
  measurementId: "G-01GBW0X67S"
};

let mainFirebaseAuth = null;
try {
  if (typeof firebase !== 'undefined') {
    if (!firebase.apps || !firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
    }
    mainFirebaseAuth = firebase.auth();
  }
} catch (e) {
  console.warn('Firebase init warning:', e);
}

function initAuthSystem() {
  // Restore session from NexaApi & localStorage
  try {
    currentUser = (window.NexaApi && window.NexaApi.getUser()) || null;
    if (!currentUser) {
      const saved = localStorage.getItem('nexa_user_session');
      if (saved) currentUser = JSON.parse(saved);
    }
    if (currentUser) {
      updateNavForLoggedInUser();
    }
  } catch (e) {}

  // Auto-sync persistent Firebase Google Auth session if present
  if (mainFirebaseAuth) {
    mainFirebaseAuth.onAuthStateChanged(async (fbUser) => {
      if (fbUser && (!window.NexaApi || !window.NexaApi.isAuthenticated())) {
        try {
          const idToken = await fbUser.getIdToken();
          const phone = localStorage.getItem('nexa_user_phone') || '9876543210';
          const syncRes = await window.NexaApi.syncFirebaseUser({
            firebaseUid: fbUser.uid,
            email: fbUser.email,
            name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Nexa Creator',
            phone: phone,
            photoUrl: fbUser.photoURL,
            idToken: idToken
          });
          currentUser = syncRes.user || window.NexaApi.getUser();
          updateNavForLoggedInUser();
          const pendingPlan = localStorage.getItem('nexa_pending_plan');
          if (pendingPlan) {
            const pendingCycle = localStorage.getItem('nexa_pending_cycle') || 'monthly';
            localStorage.removeItem('nexa_pending_plan');
            localStorage.removeItem('nexa_pending_cycle');
            setTimeout(() => triggerPlanCheckout(pendingPlan, pendingCycle), 400);
          }
        } catch (err) {
          console.warn('[AutoAuth] silent sync:', err.message);
        }
      }
    });
  }

  const loginModal = document.getElementById('loginModal');
  const loginTriggers = document.querySelectorAll('[data-open-login]');
  const loginClose = document.getElementById('closeLoginBtn');

  loginTriggers.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (window.NexaApi && window.NexaApi.isAuthenticated()) {
        window.location.href = '/profile.html';
      } else {
        openLoginModal();
      }
    });
  });

  loginClose?.addEventListener('click', () => loginModal?.classList.remove('open'));
  loginModal?.addEventListener('click', (e) => {
    if (e.target === loginModal) loginModal.classList.remove('open');
  });

  // Modal Auth View Switcher Tabs (Google vs Email)
  const tabGoogle = document.getElementById('tabGoogleAuthBtn');
  const tabEmail = document.getElementById('tabEmailAuthBtn');
  const viewGoogle = document.getElementById('googleAuthView');
  const viewEmail = document.getElementById('emailAuthView');

  tabGoogle?.addEventListener('click', () => {
    tabGoogle.classList.add('active');
    tabEmail?.classList.remove('active');
    if (viewGoogle) viewGoogle.style.display = 'block';
    if (viewEmail) viewEmail.style.display = 'none';
  });

  tabEmail?.addEventListener('click', () => {
    tabEmail.classList.add('active');
    tabGoogle?.classList.remove('active');
    if (viewEmail) viewEmail.style.display = 'block';
    if (viewGoogle) viewGoogle.style.display = 'none';
  });

  // Google Sign-In Action inside Modal
  const googleBtn = document.getElementById('googleSignInActionBtn');
  googleBtn?.addEventListener('click', async () => {
    const phoneInput = document.getElementById('googlePhoneInput');
    const phone = (phoneInput?.value || '').trim();
    const cleanDigits = phone.replace(/\D/g, '');

    if (cleanDigits.length < 10) {
      showToast('⚠️ Please enter your 10-digit mobile number (+91) first', true);
      phoneInput?.focus();
      return;
    }

    const cleanPhone = cleanDigits.slice(-10);
    localStorage.setItem('nexa_user_phone', cleanPhone);

    if (!mainFirebaseAuth) {
      showToast('Authentication service is initializing. Please try again.', true);
      return;
    }

    const originalHtml = googleBtn.innerHTML;
    googleBtn.disabled = true;
    googleBtn.innerHTML = '<span>Connecting to Google... ⏳</span>';

    try {
      showToast('🔄 Opening Google Account Chooser...');
      const provider = new firebase.auth.GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const res = await mainFirebaseAuth.signInWithPopup(provider);
      const fbUser = res.user;
      const idToken = await fbUser.getIdToken();

      showToast('⚡ Syncing your account with Nexa Cloud...');
      const syncRes = await window.NexaApi.syncFirebaseUser({
        firebaseUid: fbUser.uid,
        email: fbUser.email,
        name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Nexa Creator',
        phone: cleanPhone,
        photoUrl: fbUser.photoURL,
        idToken: idToken
      });

      currentUser = syncRes.user || window.NexaApi.getUser();
      updateNavForLoggedInUser();
      loginModal?.classList.remove('open');
      showToast(`🎉 Signed in as ${currentUser?.name || 'Creator'}!`);

      // If user had clicked a plan before signing in, trigger checkout!
      const pendingPlan = localStorage.getItem('nexa_pending_plan');
      const pendingCycle = localStorage.getItem('nexa_pending_cycle') || 'monthly';
      if (pendingPlan) {
        localStorage.removeItem('nexa_pending_plan');
        localStorage.removeItem('nexa_pending_cycle');
        setTimeout(() => triggerPlanCheckout(pendingPlan, pendingCycle), 500);
      }
    } catch (err) {
      console.error('Google Sign-In Error:', err);
      if (err.code === 'auth/popup-closed-by-user' || err.code === 'auth/cancelled-popup-request') {
        showToast('Google sign-in was cancelled.', true);
      } else {
        showToast(err.message || 'Google sign-in failed. Please try again.', true);
      }
    } finally {
      googleBtn.disabled = false;
      googleBtn.innerHTML = originalHtml;
    }
  });

  // Email/Password Login Form inside Modal
  const emailForm = document.getElementById('emailLoginForm');
  emailForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const phoneInput = document.getElementById('emailPhoneInput');
    const emailInput = document.getElementById('emailAuthInput');
    const passInput = document.getElementById('emailPasswordInput');

    const phone = (phoneInput?.value || '').trim();
    const email = (emailInput?.value || '').trim();
    const password = passInput?.value || '';

    const cleanDigits = phone.replace(/\D/g, '');
    if (cleanDigits.length < 10) {
      showToast('⚠️ Please enter your 10-digit mobile number (+91) first', true);
      phoneInput?.focus();
      return;
    }

    if (!email || !password) {
      showToast('Please enter your email and password.', true);
      return;
    }

    const submitBtn = emailForm.querySelector('button[type="submit"]');
    const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span>Signing in... ⏳</span>';
    }

    try {
      let res;
      try {
        res = await window.NexaApi.login(email, password);
      } catch (loginErr) {
        // If account doesn't exist, automatically register for user convenience
        const userName = email.split('@')[0] || 'Nexa Creator';
        const cleanHandle = userName.replace(/[^a-z0-9_]/gi, '').toLowerCase();
        res = await window.NexaApi.register(userName, email, password, cleanDigits.slice(-10), cleanHandle);
      }

      currentUser = res.user || window.NexaApi.getUser();
      localStorage.setItem('nexa_user_phone', cleanDigits.slice(-10));
      updateNavForLoggedInUser();
      loginModal?.classList.remove('open');
      showToast(`🎉 Welcome, ${currentUser?.name || 'Creator'}!`);

      // If user had a pending plan checkout, resume immediately
      const pendingPlan = localStorage.getItem('nexa_pending_plan');
      const pendingCycle = localStorage.getItem('nexa_pending_cycle') || 'monthly';
      if (pendingPlan) {
        localStorage.removeItem('nexa_pending_plan');
        localStorage.removeItem('nexa_pending_cycle');
        setTimeout(() => triggerPlanCheckout(pendingPlan, pendingCycle), 500);
      }
    } catch (err) {
      console.error('Email Auth Error:', err);
      showToast(err.message || 'Authentication failed. Please verify credentials.', true);
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = origBtnHtml;
      }
    }
  });
}

function openLoginModal() {
  const modal = document.getElementById('loginModal');
  const viewGoogle = document.getElementById('googleAuthView');
  const viewEmail = document.getElementById('emailAuthView');
  const tabGoogle = document.getElementById('tabGoogleAuthBtn');
  const tabEmail = document.getElementById('tabEmailAuthBtn');

  if (viewGoogle) viewGoogle.style.display = 'block';
  if (viewEmail) viewEmail.style.display = 'none';
  tabGoogle?.classList.add('active');
  tabEmail?.classList.remove('active');

  modal?.classList.add('open');
}

function updateNavForLoggedInUser() {
  const actionsWrap = document.querySelector('.nav-actions');
  let user = (window.NexaApi && window.NexaApi.getUser()) || currentUser;
  if (!user) {
    try {
      user = JSON.parse(localStorage.getItem('nexa_user_session') || 'null');
    } catch (_) {}
  }

  // 1. Permanently hide Floating Claim Bar if user has already claimed a handle!
  const hasClaimed = (user && user.handle) || localStorage.getItem('nexa_claimed_handle');
  const claimBar = document.getElementById('claimFloatingBar');
  if (hasClaimed && claimBar) {
    claimBar.style.display = 'none';
  }

  // Also update any navbar claim links
  document.querySelectorAll('a[href="/claim"]').forEach(link => {
    if (hasClaimed) {
      link.innerHTML = `My Bio Studio 🌟`;
      link.href = '/bio-builder.html';
    }
  });

  if (!actionsWrap || !user) return;

  // 2. Hide ALL guest auth buttons from navbar
  document.querySelectorAll('.nav-actions a[href="/login"], .nav-actions a[href="/signup"], [data-open-login]').forEach(el => {
    el.style.display = 'none';
  });

  // 3. Hide guest buttons from mobile drawer
  document.querySelectorAll('.drawer-links a[href="/login"], .drawer-links a[href="/signup"]').forEach(el => {
    el.closest('li')?.remove();
  });
  document.querySelectorAll('.mobile-nav-drawer .btn-outline[href="/login"], .mobile-nav-drawer .btn-secondary[href="/signup"]').forEach(el => {
    el.style.display = 'none';
  });

  // 4. Render clean, professional User Chip in navbar
  const existingChip = document.getElementById('navUserChip');
  if (existingChip) existingChip.remove();

  const userInitial = (user.name || user.email || 'U').charAt(0).toUpperCase();
  const userName = user.name || (user.email ? user.email.split('@')[0] : 'Creator');
  const userHandle = user.handle ? `@${user.handle}` : '';

  const userChip = document.createElement('div');
  userChip.id = 'navUserChip';
  userChip.className = 'user-account-chip';
  userChip.style.cursor = 'pointer';
  userChip.innerHTML = `
    <div class="user-chip-avatar">${userInitial}</div>
    <div style="text-align:left; line-height:1.2;">
      <div class="user-chip-name">${escapeHtml(userName)}</div>
      <div style="font-size:0.68rem; color:var(--primary); font-weight:700;">${userHandle || '● Dashboard'}</div>
    </div>
  `;
  userChip.addEventListener('click', () => {
    window.location.href = '/profile.html';
  });

  // Add Sign Out button next to it
  const existingLogoutBtn = document.getElementById('navQuickLogoutBtn');
  if (existingLogoutBtn) existingLogoutBtn.remove();

  const logoutBtn = document.createElement('button');
  logoutBtn.id = 'navQuickLogoutBtn';
  logoutBtn.type = 'button';
  logoutBtn.className = 'btn btn-sm btn-outline';
  logoutBtn.style.padding = '6px 12px';
  logoutBtn.style.fontSize = '0.78rem';
  logoutBtn.style.fontWeight = '700';
  logoutBtn.style.color = '#ef4444';
  logoutBtn.style.cursor = 'pointer';
  logoutBtn.innerText = 'Sign Out';
  logoutBtn.addEventListener('click', () => {
    if (window.NexaApi) {
      NexaApi.setToken(null);
      NexaApi.setUser(null);
    }
    localStorage.removeItem('nexa_user_session');
    localStorage.removeItem('nexa_auth_token');
    window.location.reload();
  });

  actionsWrap.prepend(logoutBtn);
  actionsWrap.prepend(userChip);

  // 5. Update Hero CTAs so they take logged in user to dashboard
  document.querySelectorAll('a[href="/signup"], a[href="#download"]').forEach(btn => {
    if (btn.closest('.hero-cta-group')) {
      btn.innerHTML = '<span>Go to Creator Dashboard ➔</span>';
      btn.href = '/profile.html';
      btn.removeAttribute('data-open-lead-modal');
    }
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   4. Direct Web Automation Control Center
   ───────────────────────────────────────────────────────────────────────────── */
function initAutomationControlCenter() {
  const modal = document.getElementById('automationControlModal');
  const closeBtn = document.getElementById('closeAutomationModalBtn');

  closeBtn?.addEventListener('click', () => modal?.classList.remove('open'));
  modal?.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('open');
  });

  // Logout button
  document.getElementById('logoutBtn')?.addEventListener('click', () => {
    localStorage.removeItem('nexa_user_session');
    currentUser = null;
    modal?.classList.remove('open');
    location.reload();
  });
}

function openAutomationCenter() {
  if (!currentUser) {
    openLoginModal();
    return;
  }

  const modal = document.getElementById('automationControlModal');
  if (!modal) return;

  document.getElementById('acUserName').innerText = currentUser.name;
  document.getElementById('acUserHandle').innerText = `@${currentUser.handle}`;
  document.getElementById('acUserPhone').innerText = `+91 ${currentUser.phone.slice(-10)}`;

  const masterToggle = document.getElementById('masterAutomationToggle');
  if (masterToggle) {
    if (currentUser.automationsActive) {
      masterToggle.classList.add('active');
    } else {
      masterToggle.classList.remove('active');
    }

    masterToggle.onclick = () => {
      currentUser.automationsActive = !currentUser.automationsActive;
      localStorage.setItem('nexa_user_session', JSON.stringify(currentUser));
      if (currentUser.automationsActive) {
        masterToggle.classList.add('active');
        showToast('⚡ All Instagram Automations Turned ON');
      } else {
        masterToggle.classList.remove('active');
        showToast('⏸️ Automations Paused');
      }
    };
  }

  // Render individual rule toggles
  const rulesList = document.getElementById('automationRulesList');
  if (rulesList) {
    rulesList.innerHTML = '';
    currentUser.rules.forEach(rule => {
      const item = document.createElement('div');
      item.className = 'rule-control-item';
      item.innerHTML = `
        <div>
          <div style="font-weight:800; font-size:0.9rem; color:#fff">${escapeHtml(rule.name)}</div>
          <div style="font-size:0.75rem; color:#9b82ff">Trigger: <code>${escapeHtml(rule.keyword)}</code></div>
        </div>
        <input type="checkbox" ${rule.active ? 'checked' : ''} style="width:20px; height:20px; accent-color:#7c5cff; cursor:pointer" onchange="toggleRule('${rule.id}', this.checked)">
      `;
      rulesList.appendChild(item);
    });
  }

  modal.classList.add('open');
}

window.toggleRule = function(ruleId, isActive) {
  if (!currentUser) return;
  const rule = currentUser.rules.find(r => r.id === ruleId);
  if (rule) {
    rule.active = isActive;
    localStorage.setItem('nexa_user_session', JSON.stringify(currentUser));
    showToast(`${rule.name} is now ${isActive ? 'ACTIVE' : 'PAUSED'}`);
  }
};

/* ─────────────────────────────────────────────────────────────────────────────
   5. Claim Your Free Username Engine (nexareply.app/@username)
   ───────────────────────────────────────────────────────────────────────────── */
function initClaimUsernameEngine() {
  const claimModal = document.getElementById('claimUsernameModal');
  const claimTriggers = document.querySelectorAll('[data-open-claim-modal], #openClaimModalBtn, .btn-claim');
  const closeBtn = document.getElementById('closeClaimModalBtn');
  const input = document.getElementById('claimHandleInput');
  const statusEl = document.getElementById('claimAvailabilityNote') || document.getElementById('claimHandleStatus');
  const confirmBtn = document.getElementById('confirmClaimBtn');

  // If user already claimed a handle, hide the floating claim bar!
  const user = (window.NexaApi && window.NexaApi.getUser()) || currentUser;
  const hasClaimed = (user && user.handle) || localStorage.getItem('nexa_claimed_handle');
  const claimBar = document.getElementById('claimFloatingBar');
  if (hasClaimed && claimBar) {
    claimBar.style.display = 'none';
  }

  claimTriggers.forEach(t => {
    t.addEventListener('click', (e) => {
      e.preventDefault();
      if (hasClaimed) {
        // User already has a bio link -> direct them to view or edit their bio
        window.location.href = '/bio-builder.html';
        return;
      }
      claimModal?.classList.add('open');
      input?.focus();
    });
  });

  closeBtn?.addEventListener('click', () => claimModal?.classList.remove('open'));
  claimModal?.addEventListener('click', (e) => {
    if (e.target === claimModal) claimModal.classList.remove('open');
  });

  let checkTimer = null;
  input?.addEventListener('input', (e) => {
    const raw = e.target.value.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    e.target.value = raw;
    clearTimeout(checkTimer);

    if (raw.length < 3) {
      if (statusEl) statusEl.innerHTML = `<span style="color:var(--text-muted)">Enter at least 3 characters (letters, numbers, underscores)</span>`;
      if (confirmBtn) confirmBtn.disabled = true;
      return;
    }

    if (statusEl) statusEl.innerHTML = `<span style="color:var(--primary)">⏳ Checking availability on cloud database...</span>`;

    checkTimer = setTimeout(async () => {
      try {
        const res = await NexaApi.checkHandle(raw);
        if (res.available) {
          if (statusEl) statusEl.innerHTML = `<span style="color:#10b981">✓ Available! Reserve <strong>nexareply.app/@${raw}</strong></span>`;
          if (confirmBtn) confirmBtn.disabled = false;
        } else {
          if (statusEl) statusEl.innerHTML = `<span style="color:#ef4444">❌ Handle @${raw} is already claimed by another creator</span>`;
          if (confirmBtn) confirmBtn.disabled = true;
        }
      } catch (err) {
        if (statusEl) statusEl.innerHTML = `<span style="color:#10b981">✓ Ready to claim <strong>nexareply.app/@${raw}</strong></span>`;
        if (confirmBtn) confirmBtn.disabled = false;
      }
    }, 280);
  });

  confirmBtn?.addEventListener('click', async () => {
    const handle = input?.value.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (!handle || handle.length < 3) {
      showToast('Please enter a valid handle (at least 3 characters)', true);
      return;
    }

    const originalText = confirmBtn.innerHTML;
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<span>Claiming & Locking Handle... ⏳</span>';

    try {
      if (window.NexaApi && window.NexaApi.isAuthenticated()) {
        // User is logged in -> permanently claim in database now
        const res = await NexaApi.claimHandle(handle);
        localStorage.setItem('nexa_claimed_handle', handle);
        claimModal?.classList.remove('open');
        showToast(`🎉 Handle @${handle} is now permanently locked to your account!`);
        setTimeout(() => {
          window.location.href = '/profile.html';
        }, 800);
      } else {
        // User not yet logged in -> store reserved handle and redirect to claim page
        localStorage.setItem('nexa_claimed_handle', handle);
        claimModal?.classList.remove('open');
        window.location.href = `/claim.html?handle=${encodeURIComponent(handle)}`;
      }
    } catch (err) {
      confirmBtn.disabled = false;
      confirmBtn.innerHTML = originalText;
      showToast(err.message || 'Could not claim handle. Please try again.', true);
    }
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   6. Templates Hub (16 Bio Templates + 7 Reply Templates)
   ───────────────────────────────────────────────────────────────────────────── */
function initTemplatesHub() {
  const bioTabBtn = document.getElementById('tabBioTemplatesBtn');
  const replyTabBtn = document.getElementById('tabReplyTemplatesBtn');
  const bioGallery = document.getElementById('bioTemplatesGallery');
  const replyGallery = document.getElementById('replyTemplatesGallery');

  bioTabBtn?.addEventListener('click', () => {
    bioTabBtn.classList.add('active');
    replyTabBtn?.classList.remove('active');
    if (bioGallery) bioGallery.style.display = 'grid';
    if (replyGallery) replyGallery.style.display = 'none';
  });

  replyTabBtn?.addEventListener('click', () => {
    replyTabBtn.classList.add('active');
    bioTabBtn?.classList.remove('active');
    if (bioGallery) bioGallery.style.display = 'none';
    if (replyGallery) replyGallery.style.display = 'grid';
  });

  // Filter chips
  const chips = document.querySelectorAll('.cat-chip');
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      const cat = chip.getAttribute('data-cat');
      filterTemplates(cat);
    });
  });
}

function filterTemplates(category) {
  const cards = document.querySelectorAll('#bioTemplatesGallery .template-item-card');
  cards.forEach(card => {
    const cardCat = card.getAttribute('data-category');
    if (category === 'all' || cardCat === category) {
      card.style.display = 'flex';
    } else {
      card.style.display = 'none';
    }
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   7. India DPDP Act 2023 Cookie Consent
   ───────────────────────────────────────────────────────────────────────────── */
function initCookieConsent() {
  const bar = document.getElementById('cookieConsentBar');
  const acceptBtn = document.getElementById('acceptCookiesBtn');
  const rejectBtn = document.getElementById('rejectCookiesBtn');
  const manageLinks = document.querySelectorAll('[data-manage-cookies]');

  const consent = localStorage.getItem('nexa_cookie_consent');
  if (!consent && bar) {
    setTimeout(() => bar.classList.add('show'), 1000);
  }

  acceptBtn?.addEventListener('click', () => {
    localStorage.setItem('nexa_cookie_consent', JSON.stringify({
      analytics: true,
      marketing: true,
      timestamp: Date.now()
    }));
    bar?.classList.remove('show');
    showToast('Preferences saved: Cookies accepted');
  });

  rejectBtn?.addEventListener('click', () => {
    localStorage.setItem('nexa_cookie_consent', JSON.stringify({
      analytics: false,
      marketing: false,
      timestamp: Date.now()
    }));
    bar?.classList.remove('show');
    showToast('Preferences saved: Non-essential cookies rejected');
  });

  manageLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      bar?.classList.add('show');
    });
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   8. Download Buttons (Google Play & APK)
   ───────────────────────────────────────────────────────────────────────────── */
function initDownloadButtons() {
  document.querySelectorAll('[data-download-apk]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      showToast('🚀 Downloading Nexa Reply APK (v1.0.0)...');
      setTimeout(() => {
        window.open('https://play.google.com/store/apps/details?id=com.antigravity.automationdm.automationdm', '_blank');
      }, 1000);
    });
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   9. Interactive Live Instagram Simulator
   ───────────────────────────────────────────────────────────────────────────── */
function initSimulator() {
  const input = document.getElementById('simCommentInput');
  const sendBtn = document.getElementById('simSendBtn');
  const feed = document.getElementById('simRepliesFeed');
  const dmContainer = document.getElementById('simDmPopupContainer');
  const chips = document.querySelectorAll('.sim-chip');

  if (!input || !sendBtn || !feed) return;

  const spintaxGreetings = ['Hey', 'Hello', 'Hi there', 'Great question'];
  const spintaxPhrases = [
    'I just sent the direct link to your DM! Check your requests 🚀',
    'Sent you the details & coupon code in your DM! 📩',
    'Check your inbox! The resource is waiting for you ✨',
    'Sent to your DM! Let me know if you need any help 🎯'
  ];

  const triggerAutomatedReply = (commentText) => {
    if (!commentText || !commentText.trim()) return;
    const cleanComment = commentText.trim();
    const commenterHandle = '@creator_' + Math.floor(100 + Math.random() * 900);

    const userCommentEl = document.createElement('div');
    userCommentEl.className = 'sim-comment-item';
    userCommentEl.innerHTML = `
      <div class="sim-avatar-sm">${commenterHandle.substring(9)}</div>
      <div class="sim-bubble-content">
        <div class="sim-author">${commenterHandle}</div>
        <div class="sim-comment-text">${escapeHtml(cleanComment)}</div>
      </div>
    `;
    feed.appendChild(userCommentEl);
    feed.scrollTop = feed.scrollHeight;

    // Show typing jitter indicator
    const typingIndicator = document.createElement('div');
    typingIndicator.className = 'sim-typing-bubble';
    typingIndicator.innerHTML = `
      <div class="typing-dots">
        <span></span><span></span><span></span>
      </div>
      <span class="typing-text">Spintax AI Typing (1.4s Human Jitter)...</span>
    `;
    feed.appendChild(typingIndicator);
    feed.scrollTop = feed.scrollHeight;

    setTimeout(() => {
      typingIndicator.remove();

      const greeting = spintaxGreetings[Math.floor(Math.random() * spintaxGreetings.length)];
      const phrase = spintaxPhrases[Math.floor(Math.random() * spintaxPhrases.length)];
      const spintaxReplyText = `${greeting} ${commenterHandle}, ${phrase}`;

      const replyEl = document.createElement('div');
      replyEl.className = 'sim-comment-item';
      replyEl.innerHTML = `
        <div class="sim-avatar-sm" style="background: linear-gradient(135deg, #6340ed, #ff5277); color:#fff; font-weight:800">⚡</div>
        <div class="sim-bubble-content sim-auto-reply">
          <span class="sim-spintax-tag">⚡ Spintax Auto-Reply (1.4s delay • No Shadowban)</span>
          <div class="sim-author">nexareply.app <svg class="verified-icon" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg></div>
          <div class="sim-comment-text">${escapeHtml(spintaxReplyText)}</div>
        </div>
      `;
      feed.appendChild(replyEl);
      feed.scrollTop = feed.scrollHeight;

      if (dmContainer) {
        dmContainer.innerHTML = `
          <div class="sim-dm-popup-card">
            <div class="sim-dm-header">
              <div style="display:flex; align-items:center; gap:6px;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="#6340ed"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                <span style="font-weight:800; font-size:0.75rem; color:#0f172a;">INSTAGRAM DIRECT MESSAGE</span>
              </div>
              <span class="sim-dm-status-badge">DELIVERED (1.4s)</span>
            </div>
            <div class="sim-dm-text">
              Hey ${commenterHandle}! 👋 Here is your instant VIP resource for <strong>"${escapeHtml(cleanComment)}"</strong>:
            </div>
            <a href="/claim?handle=${encodeURIComponent(cleanComment.replace(/[^a-z0-9_]/g, ''))}" class="sim-dm-cta-btn">
              <span>👉 Access VIP Link & Free Bio Studio ➔</span>
            </a>
            <div class="sim-dm-compliance-footer">
              🔒 Official Meta Graph API v20.0 • Follower-Gate Verified
            </div>
          </div>
        `;
        feed.scrollTop = feed.scrollHeight;
      }

      showToast(`⚡ DM Dispatched to ${commenterHandle} with Spintax rotation`);
    }, 1200);

    input.value = '';
  };

  sendBtn.addEventListener('click', () => triggerAutomatedReply(input.value));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      triggerAutomatedReply(input.value);
    }
  });

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      const text = chip.getAttribute('data-trigger') || chip.innerText.replace('#', '');
      input.value = text;
      triggerAutomatedReply(text);
    });
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   10. Pricing & ROI Calculator
   ───────────────────────────────────────────────────────────────────────────── */
function initPricingToggle() {
  const switchEl = document.getElementById('pricingSwitch');
  const monthlyLabel = document.getElementById('monthlyLabel');
  const annualLabel = document.getElementById('annualLabel');
  if (!switchEl) return;

  let isAnnual = true;

  const plansData = {
    creator: {
      annual: { price: '₹349', period: '/mo', strike: '₹399/mo', sub: 'Billed ₹4,199 /year • Save 15%' },
      monthly: { price: '₹399', period: '/mo', strike: '', sub: 'Billed monthly • Up to 5 Accounts' }
    },
    growth: {
      annual: { price: '₹629', period: '/mo', strike: '₹899/mo', sub: 'Billed ₹7,550 /year • Save 30%' },
      monthly: { price: '₹899', period: '/mo', strike: '', sub: 'Billed monthly • Up to 10 Accounts' }
    },
    scale: {
      annual: { price: '₹1,799', period: '/mo', strike: '', sub: 'Monthly Billing Only • Up to 20 Accounts' },
      monthly: { price: '₹1,799', period: '/mo', strike: '', sub: 'Monthly Billing Only • Up to 20 Accounts' }
    }
  };

  const update = () => {
    if (isAnnual) {
      switchEl.classList.add('annual');
      annualLabel?.classList.add('active');
      monthlyLabel?.classList.remove('active');
    } else {
      switchEl.classList.remove('annual');
      annualLabel?.classList.remove('active');
      monthlyLabel?.classList.add('active');
    }

    ['creator', 'growth', 'scale'].forEach(key => {
      const p = document.getElementById(`${key}Price`);
      const prd = document.getElementById(`${key}Period`);
      const str = document.getElementById(`${key}Strike`);
      const sub = document.getElementById(`${key}Subtext`);
      const data = isAnnual ? plansData[key].annual : plansData[key].monthly;
      if (p) p.innerText = data.price;
      if (prd) prd.innerText = data.period;
      if (str) str.innerText = data.strike;
      if (sub) sub.innerText = data.sub;
    });
  };

  switchEl.addEventListener('click', () => { isAnnual = !isAnnual; update(); });
  monthlyLabel?.addEventListener('click', () => { isAnnual = false; update(); });
  annualLabel?.addEventListener('click', () => { isAnnual = true; update(); });
  update();
}

function initRoiCalculator() {
  const cSlider = document.getElementById('calcCommentsSlider');
  const pSlider = document.getElementById('calcPriceSlider');
  const cvSlider = document.getElementById('calcConvSlider');

  const cVal = document.getElementById('calcCommentsVal');
  const pVal = document.getElementById('calcPriceVal');
  const cvVal = document.getElementById('calcConvVal');

  const rRev = document.getElementById('calcResultRevenue');
  const rOrd = document.getElementById('calcResultOrders');
  const rHrs = document.getElementById('calcResultHours');

  if (!cSlider || !pSlider || !cvSlider) return;

  const calc = () => {
    const comments = parseInt(cSlider.value, 10);
    const price = parseInt(pSlider.value, 10);
    const convRate = parseFloat(cvSlider.value) / 100;

    if (cVal) cVal.innerText = comments.toLocaleString('en-IN') + ' comments/mo';
    if (pVal) pVal.innerText = '₹' + price.toLocaleString('en-IN');
    if (cvVal) cvVal.innerText = (convRate * 100).toFixed(1) + '%';

    const dmsOpened = comments * 0.85;
    const orders = Math.round(dmsOpened * convRate);
    const totalExtraRevenue = orders * price;
    const hoursSaved = Math.round((comments * 1.5) / 60);

    if (rRev) rRev.innerText = '₹' + totalExtraRevenue.toLocaleString('en-IN');
    if (rOrd) rOrd.innerText = orders.toLocaleString('en-IN') + ' Extra Orders';
    if (rHrs) rHrs.innerText = hoursSaved.toLocaleString('en-IN') + ' Hours';
  };

  [cSlider, pSlider, cvSlider].forEach(s => s.addEventListener('input', calc));
  calc();
}

function initFaqAccordion() {
  document.querySelectorAll('.faq-item').forEach(item => {
    const q = item.querySelector('.faq-question');
    q?.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!isOpen) item.classList.add('open');
    });
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   11. Razorpay Pro Subscriptions & Cross-Platform Entitlement Bridge
   ───────────────────────────────────────────────────────────────────────────── */
function initPricingCheckout() {
  const buyBtns = document.querySelectorAll('[data-buy-plan]');

  // Check if returning user had selected a plan before logging in
  const pendingPlan = localStorage.getItem('nexa_pending_plan');
  const pendingCycle = localStorage.getItem('nexa_pending_cycle') || 'monthly';
  if (pendingPlan && window.NexaApi && window.NexaApi.isAuthenticated()) {
    localStorage.removeItem('nexa_pending_plan');
    localStorage.removeItem('nexa_pending_cycle');
    setTimeout(() => {
      triggerPlanCheckout(pendingPlan, pendingCycle);
    }, 600);
  }

  buyBtns.forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      const plan = btn.getAttribute('data-buy-plan') || 'creator';
      const switchEl = document.getElementById('pricingSwitch');
      let billingCycle = switchEl?.classList.contains('annual') ? 'annual' : 'monthly';
      if (plan === 'scale') {
        billingCycle = 'monthly';
      }

      await triggerPlanCheckout(plan, billingCycle, btn);
    });
  });
}

async function triggerPlanCheckout(plan, billingCycle = 'monthly', triggerBtn = null) {
  if (plan === 'scale') billingCycle = 'monthly';

  let user = (window.NexaApi && window.NexaApi.getUser()) || currentUser;
  let isAuthed = window.NexaApi && window.NexaApi.isAuthenticated();

  // If local token missing but Firebase user is active, silently sync first!
  if (!isAuthed && mainFirebaseAuth && mainFirebaseAuth.currentUser) {
    try {
      const fbUser = mainFirebaseAuth.currentUser;
      const idToken = await fbUser.getIdToken();
      const phone = localStorage.getItem('nexa_user_phone') || '9876543210';
      const syncRes = await window.NexaApi.syncFirebaseUser({
        firebaseUid: fbUser.uid,
        email: fbUser.email,
        name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Nexa Creator',
        phone: phone,
        photoUrl: fbUser.photoURL,
        idToken: idToken
      });
      user = syncRes.user || window.NexaApi.getUser();
      currentUser = user;
      isAuthed = window.NexaApi.isAuthenticated();
      updateNavForLoggedInUser();
    } catch (_) {}
  }

  if (!isAuthed || !user) {
    localStorage.setItem('nexa_pending_plan', plan);
    localStorage.setItem('nexa_pending_cycle', billingCycle);
    showToast(`Please sign in or create an account to activate your ${plan.toUpperCase()} plan.`);
    const modal = document.getElementById('loginModal');
    if (modal) {
      openLoginModal();
    } else {
      setTimeout(() => {
        window.location.href = `/login.html?plan=${encodeURIComponent(plan)}&cycle=${encodeURIComponent(billingCycle)}`;
      }, 700);
    }
    return;
  }

  const btn = triggerBtn || document.querySelector(`[data-buy-plan="${plan}"]`);
  const originalText = btn ? btn.innerHTML : '';
  if (btn) {
    if (btn.disabled) return;
    btn.disabled = true;
    btn.innerHTML = '<span>Securing Order... 🔒</span>';
  }

  try {
    const orderData = await window.NexaApi.createRazorpayOrder(plan, billingCycle);

    const openSimulator = () => {
      openRazorpayModalFallback(orderData, plan, billingCycle, btn, originalText);
    };

    if (typeof Razorpay !== 'undefined') {
      try {
        const rzpOptions = {
          key: orderData.keyId,
          amount: orderData.amount,
          currency: orderData.currency || 'INR',
          name: 'Nexa Reply',
          description: `${plan.toUpperCase()} Subscription (${billingCycle === 'annual' ? 'Annual - Save 30%' : 'Monthly'})`,
          image: '/assets/nexaonly_logo.png',
          prefill: {
            name: orderData.userName || user.name || '',
            email: orderData.userEmail || user.email || '',
            contact: orderData.userPhone || user.phone || ''
          },
          theme: { color: '#6340ed' },
          handler: async function (response) {
            if (btn) btn.innerHTML = '<span>Activating Pro Plan... ⏳</span>';
            try {
              const verifyRes = await window.NexaApi.verifyRazorpayPayment({
                paymentId: response.razorpay_payment_id || `pay_${Date.now()}`,
                orderId: response.razorpay_order_id || orderData.orderId,
                signature: response.razorpay_signature || 'rzp_verified_sig',
                plan: plan,
                billingCycle: billingCycle,
                amountFormatted: orderData.amountFormatted
              });
              showToast(`🎉 Congratulations! Your ${plan.toUpperCase()} Plan is now active across Web & App!`);
              setTimeout(() => {
                window.location.href = '/profile.html';
              }, 1200);
            } catch (verifyErr) {
              if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalText;
              }
              showToast(verifyErr.message || 'Payment verification failed', true);
            }
          },
          modal: {
            ondismiss: function () {
              if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalText;
              }
            }
          }
        };
        const rzp = new Razorpay(rzpOptions);
        rzp.on('payment.failed', function (resp) {
          if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalText;
          }
          showToast(resp.error?.description || 'Payment Failed', true);
        });
        rzp.open();
      } catch (_) {
        openSimulator();
      }
    } else {
      openSimulator();
    }
  } catch (err) {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = originalText;
    }
    const isAuthErr = err.code === 'INVALID_SESSION' || err.code === 'SIGN_IN_REQUIRED' || err.status === 401;
    if (isAuthErr) {
      localStorage.setItem('nexa_pending_plan', plan);
      localStorage.setItem('nexa_pending_cycle', billingCycle);
      showToast('Your session has expired. Please sign in again to activate your plan.', true);
      const modal = document.getElementById('loginModal');
      if (modal) {
        openLoginModal();
      } else {
        setTimeout(() => {
          window.location.href = `/login.html?plan=${encodeURIComponent(plan)}&cycle=${encodeURIComponent(billingCycle)}`;
        }, 800);
      }
      return;
    }
    showToast(err.message || 'Failed to initiate Razorpay checkout', true);
  }
}

function openRazorpayModalFallback(orderData, plan, billingCycle, btn, originalText) {
  let modal = document.getElementById('razorpaySimModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'razorpaySimModal';
    modal.className = 'modal-backdrop';
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div class="modal-content" style="max-width:440px; padding:28px 24px; border-radius:18px; text-align:center;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
        <div style="display:flex; align-items:center; gap:8px;">
          <img src="/assets/nexaonly_logo.png" style="width:28px; height:28px; border-radius:6px;" alt="Nexa">
          <span style="font-weight:800; font-size:1rem; color:var(--text-main);">Razorpay Secure Checkout</span>
        </div>
        <button type="button" id="closeRzpSimBtn" style="background:none; border:none; font-size:1.4rem; color:var(--text-muted); cursor:pointer;">&times;</button>
      </div>

      <div style="background:#f8fafc; border:1px solid var(--border-subtle); border-radius:12px; padding:18px; margin-bottom:18px; text-align:left;">
        <div style="font-size:0.8rem; color:var(--text-muted); text-transform:uppercase; font-weight:700;">Order Summary</div>
        <div style="font-size:1.3rem; font-weight:900; color:var(--text-main); margin:4px 0;">
          ${escapeHtml(orderData.amountFormatted || '₹499')}
        </div>
        <div style="font-size:0.85rem; color:var(--primary); font-weight:700;">
          ${escapeHtml(plan.toUpperCase())} Plan (${billingCycle === 'annual' ? 'Annual - Save 30%' : 'Monthly'})
        </div>
        <div style="font-size:0.75rem; color:var(--text-dim); margin-top:6px;">
          Order ID: <code>${escapeHtml(orderData.orderId)}</code>
        </div>
      </div>

      <div style="font-size:0.82rem; color:var(--text-muted); margin-bottom:18px; line-height:1.5;">
        🔒 256-Bit SSL Encrypted. Supports UPI (Google Pay, PhonePe, Paytm), Credit/Debit Cards, NetBanking.
      </div>

      <button type="button" id="confirmRzpPaymentBtn" class="btn btn-primary btn-glow" style="width:100%; padding:14px; font-size:1rem; font-weight:800; margin-bottom:10px;">
        <span>Simulate Successful UPI Payment ➔</span>
      </button>

      <div style="font-size:0.72rem; color:var(--text-dim);">
        Cross-Platform Sync: Subscription instantly syncs to Flutter Mobile App.
      </div>
    </div>
  `;

  modal.classList.add('open');

  document.getElementById('closeRzpSimBtn')?.addEventListener('click', () => {
    modal.classList.remove('open');
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = originalText;
    }
  });

  document.getElementById('confirmRzpPaymentBtn')?.addEventListener('click', async () => {
    const payBtn = document.getElementById('confirmRzpPaymentBtn');
    if (payBtn) {
      payBtn.disabled = true;
      payBtn.innerHTML = '<span>Verifying HMAC Signature... ⏳</span>';
    }

    try {
      const mockPayId = `pay_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
      await window.NexaApi.verifyRazorpayPayment({
        paymentId: mockPayId,
        orderId: orderData.orderId,
        signature: 'simulated_rzp_sig_' + Date.now(),
        plan: plan,
        billingCycle: billingCycle,
        amountFormatted: orderData.amountFormatted
      });

      modal.classList.remove('open');
      showToast(`🎉 Payment Success! Your ${plan.toUpperCase()} Plan is now active across Web & App!`);
      setTimeout(() => {
        window.location.href = '/profile.html';
      }, 1000);
    } catch (err) {
      if (payBtn) {
        payBtn.disabled = false;
        payBtn.innerHTML = '<span>Simulate Successful UPI Payment ➔</span>';
      }
      showToast(err.message || 'Payment simulation failed', true);
    }
  });
}

function showToast(message) {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<span>⚡</span><span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#039;');
}
