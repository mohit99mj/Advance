/**
 * Nexa Reply — Production Web API Client
 * Seamlessly connects the website to the AWS DynamoDB / REST Backend
 * Works identically in local development and production (nexareply.app)
 */

(function (window) {
  'use strict';

  // Determine active backend REST endpoint
  const LIVE_AWS_URL = 'https://y01q3vfek1.execute-api.us-east-1.amazonaws.com/default';
  
  const isLocal = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
  // If hosted on Express server locally, use /api/v1; otherwise use live AWS endpoint
  const API_BASE = isLocal ? '/api/v1' : LIVE_AWS_URL;

  const TOKEN_KEY = 'nexa_auth_token';
  const USER_KEY = 'nexa_user_session';
  const PHONE_KEY = 'nexa_user_phone';

  const NexaApi = {
    baseUrl: API_BASE,

    getToken() {
      const t = localStorage.getItem(TOKEN_KEY);
      if (!t || t === 'null' || t === 'undefined') return null;
      return t;
    },

    setToken(token) {
      if (token && token !== 'null' && token !== 'undefined') {
        localStorage.setItem(TOKEN_KEY, token);
      } else {
        localStorage.removeItem(TOKEN_KEY);
      }
    },

    getUser() {
      try {
        const raw = localStorage.getItem(USER_KEY);
        if (!raw || raw === 'null' || raw === 'undefined') return null;
        return JSON.parse(raw);
      } catch (_) {
        return null;
      }
    },

    setUser(user) {
      if (user) {
        localStorage.setItem(USER_KEY, JSON.stringify(user));
        if (user.phone) {
          localStorage.setItem(PHONE_KEY, user.phone);
        }
      } else {
        localStorage.removeItem(USER_KEY);
      }
    },

    isAuthenticated() {
      const token = this.getToken();
      const user = this.getUser();
      return !!(token && user && (user.id || user.email));
    },

    async request(path, options = {}) {
      const url = `${this.baseUrl}${path.startsWith('/') ? path : '/' + path}`;
      const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        ...(options.headers || {})
      };

      const token = options.token || this.getToken();
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const fetchOptions = {
        method: options.method || 'GET',
        headers: headers,
      };

      if (options.body && options.method !== 'GET') {
        fetchOptions.body = typeof options.body === 'string' ? options.body : JSON.stringify(options.body);
      }

      try {
        const res = await fetch(url, fetchOptions);
        const data = await res.json().catch(() => ({}));

        if (!res.ok || data.success === false) {
          const isAuthError = res.status === 401 || data.error === 'INVALID_SESSION' || data.error === 'SIGN_IN_REQUIRED' || data.error === 'SYNC_ACCOUNT_REQUIRED';
          if (isAuthError) {
            this.setToken(null);
            this.setUser(null);
            localStorage.removeItem(TOKEN_KEY);
            localStorage.removeItem(USER_KEY);
          }
          const errMsg = data.message || (isAuthError ? 'Your session has expired. Please sign in again.' : (data.error || `Request failed (${res.status})`));
          const err = new Error(errMsg);
          err.code = data.error || (isAuthError ? 'INVALID_SESSION' : 'ERROR');
          err.status = res.status;
          throw err;
        }

        return data;
      } catch (err) {
        console.error(`[NexaApi] Error on ${path}:`, err);
        throw err;
      }
    },

    /**
     * Authenticate directly with Email & Password via Backend API
     */
    async login(email, password) {
      if (!email || !password) throw new Error('Email and password are required');
      const data = await this.request('/auth/login', {
        method: 'POST',
        body: { email, password }
      });
      if (data.token) this.setToken(data.token);
      if (data.user) this.setUser(data.user);
      return data;
    },

    /**
     * Register a new user with Email, Password & Mobile number
     */
    async register(name, email, password, phone, handle) {
      if (!name || !email || !password) throw new Error('Name, email, and password are required');
      const data = await this.request('/auth/register', {
        method: 'POST',
        body: { name, email, password, phone, handle }
      });
      if (data.token) this.setToken(data.token);
      if (data.user) this.setUser(data.user);
      return data;
    },

    /**
     * Syncs Firebase authenticated user with AWS DynamoDB backend
     */
    async syncFirebaseUser({ firebaseUid, email, name, phone, photoUrl, idToken }) {
      if (!idToken) throw new Error('Firebase authentication token is required');

      const data = await this.request('/auth/sync-firebase', {
        method: 'POST',
        token: idToken,
        body: {
          firebaseUid: firebaseUid,
          email: email,
          name: name,
          phone: phone,
          photoUrl: photoUrl
        }
      });

      if (data.token) {
        this.setToken(data.token);
      } else {
        this.setToken(idToken);
      }

      if (data.user) {
        this.setUser(data.user);
      }

      return data;
    },

    /**
     * Fetch current user profile from AWS backend
     */
    async fetchMe() {
      const data = await this.request('/auth/me');
      if (data.user) {
        this.setUser(data.user);
      }
      return data.user || null;
    },

    /**
     * Update user profile (name, phone) in DynamoDB
     */
    async updateProfile({ name, phone }) {
      const data = await this.request('/users/profile', {
        method: 'POST',
        body: { name, phone }
      });
      const currentUser = this.getUser() || {};
      if (name) currentUser.name = name;
      if (phone) currentUser.phone = phone;
      this.setUser(currentUser);
      return data;
    },

    /**
     * Check handle availability in real-time against server database
     */
    async checkHandle(handle) {
      if (!handle) return { available: false, message: 'Handle is required' };
      const clean = handle.toLowerCase().replace(/[^a-z0-9_]/g, '');
      return await this.request(`/handle/check?handle=${encodeURIComponent(clean)}`);
    },

    /**
     * Claim and permanently lock handle to authenticated user's account
     */
    async claimHandle(handle) {
      if (!handle) throw new Error('Handle is required');
      const clean = handle.toLowerCase().replace(/[^a-z0-9_]/g, '');
      const data = await this.request('/handle/claim', {
        method: 'POST',
        body: { handle: clean }
      });
      const user = this.getUser() || {};
      user.handle = clean;
      this.setUser(user);
      return data;
    },

    /**
     * Fetch public creator bio profile by handle
     */
    async fetchBio(handle) {
      if (!handle) return null;
      const clean = handle.toLowerCase().replace(/[^a-z0-9_]/g, '');
      return await this.request(`/bio/profile?handle=${encodeURIComponent(clean)}`);
    },

    /**
     * Save and publish creator bio profile
     */
    async saveBio(bioData) {
      if (!bioData) throw new Error('Bio data is required');
      return await this.request('/bio/save', {
        method: 'POST',
        body: { bioData }
      });
    },

    /**
     * Fetch connected Instagram accounts
     */
    async fetchAccounts() {
      const data = await this.request('/accounts');
      return data.accounts || [];
    },

    /**
     * Create Razorpay subscription order
     */
    async createRazorpayOrder(plan = 'creator', billingCycle = 'monthly') {
      return await this.request('/billing/razorpay/create-order', {
        method: 'POST',
        body: { plan, billingCycle }
      });
    },

    /**
     * Verify Razorpay payment and upgrade account
     */
    async verifyRazorpayPayment(paymentData) {
      const res = await this.request('/billing/razorpay/verify-payment', {
        method: 'POST',
        body: paymentData
      });
      if (res.user) {
        this.setUser(res.user);
      }
      return res;
    },

    /**
     * Fetch active automations
     */
    async fetchAutomations(igAccountId) {
      const qs = igAccountId ? `?igAccountId=${encodeURIComponent(igAccountId)}` : '';
      const data = await this.request(`/automations${qs}`);
      return data.automations || [];
    },

    /**
     * Toggle automation active state
     */
    async toggleAutomation(id, isEnabled) {
      return await this.request(`/automations/${encodeURIComponent(id)}/toggle`, {
        method: 'PATCH',
        body: { isEnabled }
      });
    },

    /**
     * Create or update an automation rule
     */
    async createAutomation(ruleData) {
      return await this.request('/automations', {
        method: 'POST',
        body: ruleData
      });
    },

    /**
     * Fetch live dashboard statistics
     */
    async fetchDashboardStats(igAccountId) {
      const qs = igAccountId ? `?igAccountId=${encodeURIComponent(igAccountId)}` : '';
      return await this.request(`/analytics/dashboard${qs}`);
    },

    /**
     * Fetch Meta OAuth URL to connect Instagram Business / Creator account
     */
    async fetchOAuthUrl(provider = 'instagram') {
      return await this.request(`/meta/auth-url?provider=${encodeURIComponent(provider)}`);
    },

    /**
     * Test a comment trigger in sandbox simulator
     */
    async simulateComment({ commentText, commenterUsername, mediaId, igAccountId }) {
      return await this.request('/simulator/test-comment', {
        method: 'POST',
        body: { commentText, commenterUsername, mediaId, igAccountId }
      });
    },

    /**
     * Sign out user completely
     */
    async logout() {
      try {
        if (typeof firebase !== 'undefined' && firebase.auth) {
          await firebase.auth().signOut().catch(() => {});
        }
      } catch (_) {}
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
      localStorage.removeItem(PHONE_KEY);
      window.location.href = '/login.html';
    }
  };

  window.NexaApi = NexaApi;
})(window);
